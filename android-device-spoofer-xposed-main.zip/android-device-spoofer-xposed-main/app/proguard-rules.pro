# ProGuard rules for Device Spoofer Xposed Module

# Keep all classes and members in the app package
-keep class com.example.devicespoofer.** { *; }

# Keep Xposed Framework classes and interfaces
-keep class de.robv.android.xposed.** { *; }
-keep interface de.robv.android.xposed.** { *; }
-keep class * implements de.robv.android.xposed.IXposedHookLoadPackage { *; }

# Keep AndroidX and support library classes
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-keepclassmembers class androidx.** { *; }

# Keep Material Design classes
-keep class com.google.android.material.** { *; }
-keep interface com.google.android.material.** { *; }

# Keep Android framework classes
-keep class android.** { *; }
-keep interface android.** { *; }

# Keep native methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# Keep custom application classes
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.app.BroadcastReceiver
-keep public class * extends android.app.ContentProvider
-keep public class * extends android.preference.Preference
-keep public class * extends android.view.View

# Keep view constructors for inflation from XML
-keepclasseswithmembers class * {
    public <init>(android.content.Context, android.util.AttributeSet);
}

# Keep enums
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# Keep Parcelable implementations
-keep class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# Keep Serializable implementations
-keep class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# Keep R classes
-keepclassmembers class **.R$* {
    public static <fields>;
}

# Keep BuildConfig
-keep class **.BuildConfig { *; }

# Keep annotation classes
-keep class * extends java.lang.annotation.Annotation { *; }
-keepclassmembers class * extends java.lang.annotation.Annotation { *; }

# Keep entry point classes
-keep public class com.example.devicespoofer.XposedInit { *; }
-keep public class com.example.devicespoofer.MainActivity { *; }
-keep public class com.example.devicespoofer.SpoofConfig { *; }

# Keep callback methods
-keepclassmembers class * {
    void after*(***);
    void before*(***);
    void handle*(***);
}

# Keep interface implementations
-keep class * implements java.lang.Runnable { *; }
-keep class * implements java.util.concurrent.Callable { *; }

# Keep exceptions
-keep public class * extends java.lang.Exception
-keep public class * extends java.lang.RuntimeException

# Keep inner classes
-keepclasseswithmembers class * {
    *** *$InnerClass*(...);
}

# Keep annotated classes
-keepclasseswithmembers class * {
    @androidx.annotation.** <fields>;
    @androidx.annotation.** <methods>;
}

# Optimize but keep line numbers for debugging
-optimizationpasses 5
-dontobfuscate
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Keep logging
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}

# Keep reflection
-keepclasseswithmembers class * {
    *** *(...) throws java.lang.Exception;
}

# Keep method signatures for Xposed hooks
-keepclasseswithmembers class * {
    *** handleLoadPackage(...);
}

# Remove logging for release builds
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
}

# Keep preferences
-keep class android.preference.** { *; }
-keep class androidx.preference.** { *; }

# Keep listener interfaces
-keep interface * {
    <methods>;
}

# Keep generic types
-keepattributes Signature

# Keep exceptions and their stack traces
-keepattributes SourceFile,LineNumberTable
-keep public class * extends java.lang.Throwable {
    <fields>;
    <methods>;
}

# Optimization settings
-optimizations !code/simplification/arithmetic,!code/simplification/cast,!field/*,!class/merging/*

# Verbose logging (optional)
# -verbose

# Print configuration (optional, useful for debugging)
# -printconfiguration proguard-configuration.txt
