package com.example.devicespoofer;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Configuration manager for device spoofing settings
 * Stores and retrieves spoofed values from SharedPreferences
 */
public class SpoofConfig {

    private static SpoofConfig instance;
    private SharedPreferences prefs;
    private static final String PREFS_NAME = "device_spoofer_prefs";

    // Configuration Keys
    private static final String KEY_ENABLED = "spoof_enabled";
    private static final String KEY_HIDE_ACCOUNTS = "hide_accounts";

    // Default spoofed values
    private static final String DEFAULT_MODEL = "SM-G950F";
    private static final String DEFAULT_DEVICE = "dreamlte";
    private static final String DEFAULT_MANUFACTURER = "samsung";
    private static final String DEFAULT_BRAND = "samsung";
    private static final String DEFAULT_IMEI = "354638092111123";
    private static final String DEFAULT_IMSI = "310410123456789";
    private static final String DEFAULT_ANDROID_ID = "9774d56d682e549c";
    private static final String DEFAULT_WIFI_MAC = "00:1A:2B:3C:4D:5E";
    private static final String DEFAULT_BT_MAC = "11:22:33:44:55:66";

    private SpoofConfig(Context context) {
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    /**
     * Get singleton instance of SpoofConfig
     */
    public static SpoofConfig getInstance() {
        return instance;
    }

    /**
     * Initialize SpoofConfig with context
     */
    public static void initialize(Context context) {
        if (instance == null) {
            instance = new SpoofConfig(context);
        }
    }

    /**
     * Check if spoofing is enabled
     */
    public boolean isEnabled() {
        return prefs.getBoolean(KEY_ENABLED, true);
    }

    /**
     * Set spoofing enabled/disabled
     */
    public void setEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_ENABLED, enabled).apply();
    }

    /**
     * Check if accounts should be hidden
     */
    public boolean isHideAccounts() {
        return prefs.getBoolean(KEY_HIDE_ACCOUNTS, false);
    }

    /**
     * Set hide accounts preference
     */
    public void setHideAccounts(boolean hide) {
        prefs.edit().putBoolean(KEY_HIDE_ACCOUNTS, hide).apply();
    }

    /**
     * Get spoofed string property
     */
    public String getSpoofedProperty(String key, String defaultValue) {
        return prefs.getString(key, defaultValue);
    }

    /**
     * Get spoofed integer property
     */
    public int getSpoofedIntProperty(String key, int defaultValue) {
        return prefs.getInt(key, defaultValue);
    }

    /**
     * Get spoofed long property
     */
    public long getSpoofedLongProperty(String key, long defaultValue) {
        return prefs.getLong(key, defaultValue);
    }

    /**
     * Set spoofed property
     */
    public void setSpoofedProperty(String key, String value) {
        prefs.edit().putString(key, value).apply();
    }

    /**
     * Set spoofed integer property
     */
    public void setSpoofedIntProperty(String key, int value) {
        prefs.edit().putInt(key, value).apply();
    }

    /**
     * Set spoofed long property
     */
    public void setSpoofedLongProperty(String key, long value) {
        prefs.edit().putLong(key, value).apply();
    }

    /**
     * Reset all settings to defaults
     */
    public void resetToDefaults() {
        prefs.edit().clear().apply();
    }

    /**
     * Get all current spoofed values as a readable string
     */
    public String getAllSpoofedValues() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Spoofed Device Information ===\n\n");

        // Build Info
        sb.append("BUILD INFO:\n");
        sb.append("Model: ").append(getSpoofedProperty("BUILD_MODEL", DEFAULT_MODEL)).append("\n");
        sb.append("Device: ").append(getSpoofedProperty("BUILD_DEVICE", DEFAULT_DEVICE)).append("\n");
        sb.append("Manufacturer: ").append(getSpoofedProperty("BUILD_MANUFACTURER", DEFAULT_MANUFACTURER)).append("\n");
        sb.append("Brand: ").append(getSpoofedProperty("BUILD_BRAND", DEFAULT_BRAND)).append("\n");
        sb.append("Product: ").append(getSpoofedProperty("BUILD_PRODUCT", "dreamlte")).append("\n");
        sb.append("Board: ").append(getSpoofedProperty("BUILD_BOARD", "universal8895")).append("\n");
        sb.append("Hardware: ").append(getSpoofedProperty("BUILD_HARDWARE", "exynos8895")).append("\n");
        sb.append("Fingerprint: ").append(getSpoofedProperty("BUILD_FINGERPRINT", 
            "samsung/dreamlte/dreamlte:9/PPR1.180610.011/G950FXXU1AQH9:user/release-keys")).append("\n");
        sb.append("Build ID: ").append(getSpoofedProperty("BUILD_ID", "PPR1.180610.011")).append("\n");
        sb.append("Build Type: ").append(getSpoofedProperty("BUILD_TYPE", "user")).append("\n\n");

        // Telephony
        sb.append("TELEPHONY:\n");
        sb.append("IMEI: ").append(getSpoofedProperty("IMEI", DEFAULT_IMEI)).append("\n");
        sb.append("IMSI: ").append(getSpoofedProperty("IMSI", DEFAULT_IMSI)).append("\n");
        sb.append("MEID: ").append(getSpoofedProperty("MEID", "A0000004201B3CA")).append("\n");
        sb.append("Phone Number: ").append(getSpoofedProperty("PHONE_NUMBER", "+1234567890")).append("\n");
        sb.append("SIM Serial: ").append(getSpoofedProperty("SIM_SERIAL", "8931000000000123456")).append("\n\n");

        // Network
        sb.append("NETWORK:\n");
        sb.append("WiFi MAC: ").append(getSpoofedProperty("WIFI_MAC", DEFAULT_WIFI_MAC)).append("\n");
        sb.append("Bluetooth MAC: ").append(getSpoofedProperty("BLUETOOTH_MAC", DEFAULT_BT_MAC)).append("\n");
        sb.append("BSSID: ").append(getSpoofedProperty("BSSID", "AA:BB:CC:DD:EE:FF")).append("\n");
        sb.append("SSID: ").append(getSpoofedProperty("SSID", "RouterName")).append("\n\n");

        // Identifiers
        sb.append("IDENTIFIERS:\n");
        sb.append("Android ID: ").append(getSpoofedProperty("ANDROID_ID", DEFAULT_ANDROID_ID)).append("\n");
        sb.append("Operator: ").append(getSpoofedProperty("SIM_OPERATOR", "31001")).append("\n");
        sb.append("Carrier: ").append(getSpoofedProperty("SIM_CARRIER", "Verizon")).append("\n\n");

        // Status
        sb.append("STATUS:\n");
        sb.append("Module Enabled: ").append(isEnabled()).append("\n");
        sb.append("Hide Accounts: ").append(isHideAccounts()).append("\n");

        return sb.toString();
    }

    /**
     * Load default configuration if not exists
     */
    public void loadDefaults() {
        if (getSpoofedProperty("BUILD_MODEL", null) == null) {
            // Set all defaults
            setSpoofedProperty("BUILD_MODEL", DEFAULT_MODEL);
            setSpoofedProperty("BUILD_DEVICE", DEFAULT_DEVICE);
            setSpoofedProperty("BUILD_MANUFACTURER", DEFAULT_MANUFACTURER);
            setSpoofedProperty("BUILD_BRAND", DEFAULT_BRAND);
            setSpoofedProperty("IMEI", DEFAULT_IMEI);
            setSpoofedProperty("IMSI", DEFAULT_IMSI);
            setSpoofedProperty("ANDROID_ID", DEFAULT_ANDROID_ID);
            setSpoofedProperty("WIFI_MAC", DEFAULT_WIFI_MAC);
            setSpoofedProperty("BLUETOOTH_MAC", DEFAULT_BT_MAC);
            setEnabled(true);
        }
    }
}
