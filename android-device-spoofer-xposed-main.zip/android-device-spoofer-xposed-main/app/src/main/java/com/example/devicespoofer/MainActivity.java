package com.example.devicespoofer;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ScrollView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Main Activity - UI for configuring device spoofing
 */
public class MainActivity extends AppCompatActivity {

    private SpoofConfig spoofConfig;
    private Switch enableSwitch;
    private Switch hideAccountsSwitch;
    private EditText modelInput;
    private EditText deviceInput;
    private EditText manufacturerInput;
    private EditText brandInput;
    private EditText imeiInput;
    private EditText imsiInput;
    private EditText androidIdInput;
    private EditText wifiMacInput;
    private EditText btMacInput;
    private EditText phoneNumberInput;
    private EditText simSerialInput;
    private TextView statusTextView;
    private Button saveButton;
    private Button resetButton;
    private Button viewAllButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize SpoofConfig
        SpoofConfig.initialize(this);
        spoofConfig = SpoofConfig.getInstance();
        spoofConfig.loadDefaults();

        // Initialize UI components
        initializeViews();
        loadCurrentValues();
        setupListeners();

        // Show initial status
        updateStatusText();
    }

    /**
     * Initialize all UI views
     */
    private void initializeViews() {
        enableSwitch = findViewById(R.id.enableSwitch);
        hideAccountsSwitch = findViewById(R.id.hideAccountsSwitch);
        modelInput = findViewById(R.id.modelInput);
        deviceInput = findViewById(R.id.deviceInput);
        manufacturerInput = findViewById(R.id.manufacturerInput);
        brandInput = findViewById(R.id.brandInput);
        imeiInput = findViewById(R.id.imeiInput);
        imsiInput = findViewById(R.id.imsiInput);
        androidIdInput = findViewById(R.id.androidIdInput);
        wifiMacInput = findViewById(R.id.wifiMacInput);
        btMacInput = findViewById(R.id.btMacInput);
        phoneNumberInput = findViewById(R.id.phoneNumberInput);
        simSerialInput = findViewById(R.id.simSerialInput);
        statusTextView = findViewById(R.id.statusTextView);
        saveButton = findViewById(R.id.saveButton);
        resetButton = findViewById(R.id.resetButton);
        viewAllButton = findViewById(R.id.viewAllButton);
    }

    /**
     * Load current values from configuration
     */
    private void loadCurrentValues() {
        enableSwitch.setChecked(spoofConfig.isEnabled());
        hideAccountsSwitch.setChecked(spoofConfig.isHideAccounts());
        modelInput.setText(spoofConfig.getSpoofedProperty("BUILD_MODEL", "SM-G950F"));
        deviceInput.setText(spoofConfig.getSpoofedProperty("BUILD_DEVICE", "dreamlte"));
        manufacturerInput.setText(spoofConfig.getSpoofedProperty("BUILD_MANUFACTURER", "samsung"));
        brandInput.setText(spoofConfig.getSpoofedProperty("BUILD_BRAND", "samsung"));
        imeiInput.setText(spoofConfig.getSpoofedProperty("IMEI", "354638092111123"));
        imsiInput.setText(spoofConfig.getSpoofedProperty("IMSI", "310410123456789"));
        androidIdInput.setText(spoofConfig.getSpoofedProperty("ANDROID_ID", "9774d56d682e549c"));
        wifiMacInput.setText(spoofConfig.getSpoofedProperty("WIFI_MAC", "00:1A:2B:3C:4D:5E"));
        btMacInput.setText(spoofConfig.getSpoofedProperty("BLUETOOTH_MAC", "11:22:33:44:55:66"));
        phoneNumberInput.setText(spoofConfig.getSpoofedProperty("PHONE_NUMBER", "+1234567890"));
        simSerialInput.setText(spoofConfig.getSpoofedProperty("SIM_SERIAL", "8931000000000123456"));
    }

    /**
     * Setup click listeners for buttons
     */
    private void setupListeners() {
        saveButton.setOnClickListener(v -> saveConfiguration());
        resetButton.setOnClickListener(v -> resetConfiguration());
        viewAllButton.setOnClickListener(v -> showAllValues());
    }

    /**
     * Save current configuration
     */
    private void saveConfiguration() {
        try {
            // Save switches
            spoofConfig.setEnabled(enableSwitch.isChecked());
            spoofConfig.setHideAccounts(hideAccountsSwitch.isChecked());

            // Save text inputs
            spoofConfig.setSpoofedProperty("BUILD_MODEL", modelInput.getText().toString());
            spoofConfig.setSpoofedProperty("BUILD_DEVICE", deviceInput.getText().toString());
            spoofConfig.setSpoofedProperty("BUILD_MANUFACTURER", manufacturerInput.getText().toString());
            spoofConfig.setSpoofedProperty("BUILD_BRAND", brandInput.getText().toString());
            spoofConfig.setSpoofedProperty("IMEI", imeiInput.getText().toString());
            spoofConfig.setSpoofedProperty("IMSI", imsiInput.getText().toString());
            spoofConfig.setSpoofedProperty("ANDROID_ID", androidIdInput.getText().toString());
            spoofConfig.setSpoofedProperty("WIFI_MAC", wifiMacInput.getText().toString());
            spoofConfig.setSpoofedProperty("BLUETOOTH_MAC", btMacInput.getText().toString());
            spoofConfig.setSpoofedProperty("PHONE_NUMBER", phoneNumberInput.getText().toString());
            spoofConfig.setSpoofedProperty("SIM_SERIAL", simSerialInput.getText().toString());

            updateStatusText();
            Toast.makeText(this, "Configuration saved! Device reboot required for changes to take effect.", 
                Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error saving configuration: " + e.getMessage(), 
                Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Reset to default configuration
     */
    private void resetConfiguration() {
        try {
            spoofConfig.resetToDefaults();
            spoofConfig.loadDefaults();
            loadCurrentValues();
            updateStatusText();
            Toast.makeText(this, "Configuration reset to defaults!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error resetting configuration: " + e.getMessage(), 
                Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Show all spoofed values
     */
    private void showAllValues() {
        String allValues = spoofConfig.getAllSpoofedValues();
        statusTextView.setText(allValues);
    }

    /**
     * Update status text display
     */
    private void updateStatusText() {
        StringBuilder status = new StringBuilder();
        status.append("Status:\n");
        status.append("Module: ").append(spoofConfig.isEnabled() ? "ENABLED" : "DISABLED").append("\n");
        status.append("Hide Accounts: ").append(spoofConfig.isHideAccounts() ? "YES" : "NO").append("\n\n");
        status.append("Current Device Info:\n");
        status.append("Model: ").append(spoofConfig.getSpoofedProperty("BUILD_MODEL", "Unknown")).append("\n");
        status.append("Device: ").append(spoofConfig.getSpoofedProperty("BUILD_DEVICE", "Unknown")).append("\n");
        status.append("IMEI: ").append(spoofConfig.getSpoofedProperty("IMEI", "Unknown")).append("\n");
        status.append("Android ID: ").append(spoofConfig.getSpoofedProperty("ANDROID_ID", "Unknown")).append("\n");
        statusTextView.setText(status.toString());
    }
}
